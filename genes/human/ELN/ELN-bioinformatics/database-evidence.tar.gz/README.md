# ELN database evidence

Run `python3 reproduce.py` from any working directory. Only Python's standard library is required; the program is offline and writes no files. The frozen official records and their retrieval receipts are supplied. `integrity.json` detects changed input bytes before reconstruction.

The program reconstructs ordered, typed Reactome paths to human P15502, retaining repeated component edges and unexpanded branches. It joins the complete saved mouse annotation collection to the literal donor terms, authenticates the donor's official identity and orthology records, verifies all 13 natural-product FASTA sequences, checks two typed ontology refinements, and reconciles the 50 raw target contexts with the 48 source assertions. Raw tissue-extension multiplicities remain visible.

`expected-projection.json` is the reproducibility target, not the source of reconstructed results. Its scientific content matches the independently checked database projection; only absolute private paths were converted to relative `raw/` locators. No article bodies, private provider logs, figure images or supplementary publication workbooks are redistributed here. This database evidence complements the precise original-access account in the ELN source guide; it does not replace primary experiments or establish equal activity of natural products.
