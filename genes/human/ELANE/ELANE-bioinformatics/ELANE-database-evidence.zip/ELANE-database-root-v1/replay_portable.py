"""Reconstruct captured database identity; no network, writes or review judgments."""
from pathlib import Path
import json,hashlib,collections
from reconstruct_paint import run as paint
D=Path(__file__).resolve().parent
def need(v,m):
 if not v:raise ValueError(m)
def read(p):return json.loads(p.read_text())
def run():
 receipts=[]
 for p in sorted((D/'raw').glob('*.receipt.json')):
  r=read(p);data=Path(str(p).removesuffix('.receipt.json')).read_bytes()
  need(hashlib.sha256(data).hexdigest()==r['sha256']and len(data)==r['bytes'],'Changed raw input '+p.name)
  need(r['status']==200,'Unsuccessful acquisition '+p.name);receipts.append(r)
 # Bundled frozen inputs are authenticated by the portable driver manifest.
 sources=read(D/'source-objects.json');need(sources==read(D/'frozen-inputs/source-objects.json'),'Sources exact')
 terms={r['id']:r for p in sorted((D/'raw').glob('QuickGO-terms-[0-9].json'))for r in read(p)['results']}
 need(set(terms)=={s['term']['id']for s in sources},'All source definitions')
 need(not any(t['isObsolete']for t in terms.values()),'Obsolete term')
 ancestry={t:read(D/'raw'/(t.replace(':','')+'-ancestors-is_a.json'))['results']for t in terms}
 need(all(len(v)==1 and v[0]['id']==t for t,v in ancestry.items()),'Typed ancestry identity')
 p=paint();need(p==read(D/'paint-replay-first.json'),'PAINT replay drift')
 records={}
 for f in sorted((D/'raw').glob('Reactome-*.json')):
  if '.receipt.'in f.name:continue
  r=read(f);ident=r['dbId']
  if ident in records:need(records[ident]==r,'Repeated Reactome entity differs')
  records[ident]=r
 slots=['catalystActivity','physicalEntity','hasMember','hasComponent','hasCandidate','input','output','hasEvent']
 def target_paths(root):
  todo=collections.deque([(root,[])]);seen=set();found=[]
  while todo:
   ident,path=todo.popleft()
   # Preserve catalytic and input/output roles separately even when they
   # converge on the same protein; shortest output paths cannot prove catalysis.
   key=(ident,path[0]['slot']if path else None,any(e['slot']=='catalystActivity'for e in path))
   if key in seen or ident not in records:continue
   seen.add(key);r=records[ident]
   if r.get('referenceEntity',{}).get('identifier')=='P08246':
    found.append({'path':path,'target_entity':ident,'target_name':r['displayName'],'reference':'P08246','species':r.get('speciesName'),'start':r.get('startCoordinate'),'end':r.get('endCoordinate')});continue
   for slot in slots:
    vs=r.get(slot,[]);vs=[vs]if isinstance(vs,dict)else vs
    for v in vs:
     n=v if isinstance(v,int)else v['dbId'];todo.append((n,path+[{'from':ident,'slot':slot,'to':n}]))
  return found
 joins=[]
 for i,s in enumerate(sources):
  if not s['original_reference_id'].startswith('Reactome:'):continue
  ref=s['original_reference_id'].split(':',1)[1];root=read(D/'raw'/('Reactome-'+ref+'.json'));paths=target_paths(root['dbId'])
  joins.append({'source_index':i,'reference':ref,'root_species':root.get('speciesName'),'target_paths':paths,'scope':'Paths reconstructed only through explicitly captured objects; no activity verdict or experimental construct identity inferred.'})
 return {'status':'PASS','retrievals':len(receipts),'source_objects':len(sources),'source_definitions':len(terms),'typed_ancestry_records':len(ancestry),'paint_target':p['target'],'paint_joins':len(p['joins']),'paint_path_records':len(p['all_target_path_IBD_IRD_records']),'canonical_sequence_length':p['target_sequence_length'],'Reactome_source_rows':len(joins),'Reactome_joins':joins,'unresolved_Reactome_rows':[x['source_index']for x in joins if not x['target_paths']],'annotation_judgments':0}
if __name__=='__main__':print(json.dumps(run(),indent=2))
